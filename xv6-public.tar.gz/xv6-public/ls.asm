
_ls:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
  }
  close(fd);
}

int main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 18             	sub    $0x18,%esp
  14:	8b 19                	mov    (%ecx),%ebx
  16:	8b 71 04             	mov    0x4(%ecx),%esi
  int i;
  int show_hidden = 0;
  int start_idx = 1;

  // Check for -a flag
  if (argc > 1 && strcmp(argv[1], "-a") == 0)
  19:	83 fb 01             	cmp    $0x1,%ebx
  1c:	7f 07                	jg     25 <main+0x25>
    show_hidden = 1;
    start_idx = 2; // Skip the -a argument
  }

  // If no directory argument provided, list current directory
  if (argc == start_idx)
  1e:	74 33                	je     53 <main+0x53>
  for (i = start_idx; i < argc; i++)
  {
    ls(argv[i], show_hidden);
  }

  exit();
  20:	e8 0e 06 00 00       	call   633 <exit>
  if (argc > 1 && strcmp(argv[1], "-a") == 0)
  25:	51                   	push   %ecx
  26:	51                   	push   %ecx
  27:	68 50 0b 00 00       	push   $0xb50
  2c:	ff 76 04             	push   0x4(%esi)
  2f:	e8 bc 03 00 00       	call   3f0 <strcmp>
  34:	83 c4 10             	add    $0x10,%esp
  37:	85 c0                	test   %eax,%eax
  39:	75 2c                	jne    67 <main+0x67>
  if (argc == start_idx)
  3b:	b8 01 00 00 00       	mov    $0x1,%eax
  40:	83 fb 02             	cmp    $0x2,%ebx
  43:	74 10                	je     55 <main+0x55>
  45:	c7 45 e4 01 00 00 00 	movl   $0x1,-0x1c(%ebp)
  4c:	bf 02 00 00 00       	mov    $0x2,%edi
  51:	eb 2d                	jmp    80 <main+0x80>
  int show_hidden = 0;
  53:	31 c0                	xor    %eax,%eax
    ls(".", show_hidden);
  55:	52                   	push   %edx
  56:	52                   	push   %edx
  57:	50                   	push   %eax
  58:	68 53 0b 00 00       	push   $0xb53
  5d:	e8 0e 01 00 00       	call   170 <ls>
    exit();
  62:	e8 cc 05 00 00       	call   633 <exit>
  int show_hidden = 0;
  67:	31 c0                	xor    %eax,%eax
  int start_idx = 1;
  69:	bf 01 00 00 00       	mov    $0x1,%edi
  int show_hidden = 0;
  6e:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  71:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
  7f:	00 
    ls(argv[i], show_hidden);
  80:	83 ec 08             	sub    $0x8,%esp
  83:	ff 75 e4             	push   -0x1c(%ebp)
  86:	ff 34 be             	push   (%esi,%edi,4)
  for (i = start_idx; i < argc; i++)
  89:	83 c7 01             	add    $0x1,%edi
    ls(argv[i], show_hidden);
  8c:	e8 df 00 00 00       	call   170 <ls>
  for (i = start_idx; i < argc; i++)
  91:	83 c4 10             	add    $0x10,%esp
  94:	39 fb                	cmp    %edi,%ebx
  96:	7f e8                	jg     80 <main+0x80>
  exit();
  98:	e8 96 05 00 00       	call   633 <exit>
  9d:	66 90                	xchg   %ax,%ax
  9f:	90                   	nop

000000a0 <fmtname>:
{
  a0:	55                   	push   %ebp
  a1:	89 e5                	mov    %esp,%ebp
  a3:	56                   	push   %esi
  a4:	53                   	push   %ebx
  a5:	8b 75 08             	mov    0x8(%ebp),%esi
  for (p = path + strlen(path); p >= path && *p != '/'; p--)
  a8:	83 ec 0c             	sub    $0xc,%esp
  ab:	56                   	push   %esi
  ac:	e8 af 03 00 00       	call   460 <strlen>
  b1:	83 c4 10             	add    $0x10,%esp
  b4:	01 f0                	add    %esi,%eax
  b6:	89 c3                	mov    %eax,%ebx
  b8:	73 0f                	jae    c9 <fmtname+0x29>
  ba:	eb 12                	jmp    ce <fmtname+0x2e>
  bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  c0:	8d 43 ff             	lea    -0x1(%ebx),%eax
  c3:	39 f0                	cmp    %esi,%eax
  c5:	72 0a                	jb     d1 <fmtname+0x31>
  c7:	89 c3                	mov    %eax,%ebx
  c9:	80 3b 2f             	cmpb   $0x2f,(%ebx)
  cc:	75 f2                	jne    c0 <fmtname+0x20>
  p++;
  ce:	83 c3 01             	add    $0x1,%ebx
  int len = strlen(p);
  d1:	83 ec 0c             	sub    $0xc,%esp
  d4:	53                   	push   %ebx
  d5:	e8 86 03 00 00       	call   460 <strlen>
  if (len >= DIRSIZ)
  da:	83 c4 10             	add    $0x10,%esp
  int len = strlen(p);
  dd:	89 c6                	mov    %eax,%esi
  if (len >= DIRSIZ)
  df:	83 f8 0d             	cmp    $0xd,%eax
  e2:	7e 0c                	jle    f0 <fmtname+0x50>
}
  e4:	8d 65 f8             	lea    -0x8(%ebp),%esp
  e7:	89 d8                	mov    %ebx,%eax
  e9:	5b                   	pop    %ebx
  ea:	5e                   	pop    %esi
  eb:	5d                   	pop    %ebp
  ec:	c3                   	ret
  ed:	8d 76 00             	lea    0x0(%esi),%esi
  memmove(buf, p, len);
  f0:	83 ec 04             	sub    $0x4,%esp
  f3:	50                   	push   %eax
  f4:	53                   	push   %ebx
  f5:	68 ec 0e 00 00       	push   $0xeec
  fa:	e8 01 05 00 00       	call   600 <memmove>
  if (is_dir) {
  ff:	8b 45 0c             	mov    0xc(%ebp),%eax
 102:	83 c4 10             	add    $0x10,%esp
 105:	85 c0                	test   %eax,%eax
 107:	74 3f                	je     148 <fmtname+0xa8>
      memset(buf + len + 1, ' ', DIRSIZ - len); // Pad the rest with spaces
 109:	b8 0e 00 00 00       	mov    $0xe,%eax
      buf[len] = '/'; // Attach slash directly to the directory name
 10e:	c6 86 ec 0e 00 00 2f 	movb   $0x2f,0xeec(%esi)
      memset(buf + len + 1, ' ', DIRSIZ - len); // Pad the rest with spaces
 115:	83 ec 04             	sub    $0x4,%esp
 118:	29 f0                	sub    %esi,%eax
 11a:	81 c6 ed 0e 00 00    	add    $0xeed,%esi
 120:	50                   	push   %eax
 121:	6a 20                	push   $0x20
 123:	56                   	push   %esi
 124:	e8 67 03 00 00       	call   490 <memset>
 129:	83 c4 10             	add    $0x10,%esp
  buf[DIRSIZ + 1] = '\0';
 12c:	c6 05 fb 0e 00 00 00 	movb   $0x0,0xefb
  return buf;
 133:	bb ec 0e 00 00       	mov    $0xeec,%ebx
}
 138:	8d 65 f8             	lea    -0x8(%ebp),%esp
 13b:	89 d8                	mov    %ebx,%eax
 13d:	5b                   	pop    %ebx
 13e:	5e                   	pop    %esi
 13f:	5d                   	pop    %ebp
 140:	c3                   	ret
 141:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      memset(buf + len, ' ', DIRSIZ - len + 1); // Pad with spaces (no slash)
 148:	b8 0f 00 00 00       	mov    $0xf,%eax
 14d:	83 ec 04             	sub    $0x4,%esp
 150:	29 f0                	sub    %esi,%eax
 152:	81 c6 ec 0e 00 00    	add    $0xeec,%esi
 158:	50                   	push   %eax
 159:	6a 20                	push   $0x20
 15b:	56                   	push   %esi
 15c:	e8 2f 03 00 00       	call   490 <memset>
 161:	83 c4 10             	add    $0x10,%esp
 164:	eb c6                	jmp    12c <fmtname+0x8c>
 166:	66 90                	xchg   %ax,%ax
 168:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 16f:	00 

00000170 <ls>:
{
 170:	55                   	push   %ebp
 171:	89 e5                	mov    %esp,%ebp
 173:	57                   	push   %edi
 174:	56                   	push   %esi
 175:	53                   	push   %ebx
 176:	81 ec 64 02 00 00    	sub    $0x264,%esp
 17c:	8b 7d 08             	mov    0x8(%ebp),%edi
  if ((fd = open(path, 0)) < 0)
 17f:	6a 00                	push   $0x0
 181:	57                   	push   %edi
 182:	e8 ec 04 00 00       	call   673 <open>
 187:	83 c4 10             	add    $0x10,%esp
 18a:	85 c0                	test   %eax,%eax
 18c:	0f 88 9e 01 00 00    	js     330 <ls+0x1c0>
  if (fstat(fd, &st) < 0)
 192:	83 ec 08             	sub    $0x8,%esp
 195:	8d b5 d4 fd ff ff    	lea    -0x22c(%ebp),%esi
 19b:	89 c3                	mov    %eax,%ebx
 19d:	56                   	push   %esi
 19e:	50                   	push   %eax
 19f:	e8 e7 04 00 00       	call   68b <fstat>
 1a4:	83 c4 10             	add    $0x10,%esp
 1a7:	85 c0                	test   %eax,%eax
 1a9:	0f 88 e1 01 00 00    	js     390 <ls+0x220>
  switch (st.type)
 1af:	0f b7 85 d4 fd ff ff 	movzwl -0x22c(%ebp),%eax
 1b6:	66 83 f8 01          	cmp    $0x1,%ax
 1ba:	74 54                	je     210 <ls+0xa0>
 1bc:	66 83 f8 02          	cmp    $0x2,%ax
 1c0:	75 39                	jne    1fb <ls+0x8b>
    printf(1, "%s %d %d %d\n", fmtname(path, 0), st.type, st.ino, st.size);
 1c2:	8b 95 e4 fd ff ff    	mov    -0x21c(%ebp),%edx
 1c8:	83 ec 08             	sub    $0x8,%esp
 1cb:	8b b5 dc fd ff ff    	mov    -0x224(%ebp),%esi
 1d1:	89 95 b4 fd ff ff    	mov    %edx,-0x24c(%ebp)
 1d7:	6a 00                	push   $0x0
 1d9:	57                   	push   %edi
 1da:	e8 c1 fe ff ff       	call   a0 <fmtname>
 1df:	5f                   	pop    %edi
 1e0:	5a                   	pop    %edx
 1e1:	8b 95 b4 fd ff ff    	mov    -0x24c(%ebp),%edx
 1e7:	52                   	push   %edx
 1e8:	56                   	push   %esi
 1e9:	6a 02                	push   $0x2
 1eb:	50                   	push   %eax
 1ec:	68 30 0b 00 00       	push   $0xb30
 1f1:	6a 01                	push   $0x1
 1f3:	e8 a8 05 00 00       	call   7a0 <printf>
    break;
 1f8:	83 c4 20             	add    $0x20,%esp
  close(fd);
 1fb:	83 ec 0c             	sub    $0xc,%esp
 1fe:	53                   	push   %ebx
 1ff:	e8 57 04 00 00       	call   65b <close>
 204:	83 c4 10             	add    $0x10,%esp
}
 207:	8d 65 f4             	lea    -0xc(%ebp),%esp
 20a:	5b                   	pop    %ebx
 20b:	5e                   	pop    %esi
 20c:	5f                   	pop    %edi
 20d:	5d                   	pop    %ebp
 20e:	c3                   	ret
 20f:	90                   	nop
    if (strlen(path) + 1 + DIRSIZ + 1 > sizeof buf)
 210:	83 ec 0c             	sub    $0xc,%esp
 213:	57                   	push   %edi
 214:	e8 47 02 00 00       	call   460 <strlen>
 219:	83 c4 10             	add    $0x10,%esp
 21c:	83 c0 10             	add    $0x10,%eax
 21f:	3d 00 02 00 00       	cmp    $0x200,%eax
 224:	0f 87 26 01 00 00    	ja     350 <ls+0x1e0>
    strcpy(buf, path);
 22a:	83 ec 08             	sub    $0x8,%esp
 22d:	57                   	push   %edi
 22e:	8d bd e8 fd ff ff    	lea    -0x218(%ebp),%edi
 234:	57                   	push   %edi
 235:	e8 86 01 00 00       	call   3c0 <strcpy>
    p = buf + strlen(buf);
 23a:	89 3c 24             	mov    %edi,(%esp)
 23d:	e8 1e 02 00 00       	call   460 <strlen>
    while (read(fd, &de, sizeof(de)) == sizeof(de))
 242:	83 c4 10             	add    $0x10,%esp
    p = buf + strlen(buf);
 245:	01 f8                	add    %edi,%eax
    *p++ = '/';
 247:	8d 48 01             	lea    0x1(%eax),%ecx
    p = buf + strlen(buf);
 24a:	89 85 a8 fd ff ff    	mov    %eax,-0x258(%ebp)
    *p++ = '/';
 250:	89 8d a4 fd ff ff    	mov    %ecx,-0x25c(%ebp)
 256:	c6 00 2f             	movb   $0x2f,(%eax)
    while (read(fd, &de, sizeof(de)) == sizeof(de))
 259:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 260:	83 ec 04             	sub    $0x4,%esp
 263:	8d 85 c4 fd ff ff    	lea    -0x23c(%ebp),%eax
 269:	6a 10                	push   $0x10
 26b:	50                   	push   %eax
 26c:	53                   	push   %ebx
 26d:	e8 d9 03 00 00       	call   64b <read>
 272:	83 c4 10             	add    $0x10,%esp
 275:	83 f8 10             	cmp    $0x10,%eax
 278:	75 81                	jne    1fb <ls+0x8b>
      if (de.inum == 0)
 27a:	66 83 bd c4 fd ff ff 	cmpw   $0x0,-0x23c(%ebp)
 281:	00 
 282:	74 dc                	je     260 <ls+0xf0>
      if (!show_hidden && de.name[0] == '.')
 284:	8b 4d 0c             	mov    0xc(%ebp),%ecx
 287:	85 c9                	test   %ecx,%ecx
 289:	75 09                	jne    294 <ls+0x124>
 28b:	80 bd c6 fd ff ff 2e 	cmpb   $0x2e,-0x23a(%ebp)
 292:	74 cc                	je     260 <ls+0xf0>
      memmove(p, de.name, DIRSIZ);
 294:	83 ec 04             	sub    $0x4,%esp
 297:	8d 85 c6 fd ff ff    	lea    -0x23a(%ebp),%eax
 29d:	6a 0e                	push   $0xe
 29f:	50                   	push   %eax
 2a0:	ff b5 a4 fd ff ff    	push   -0x25c(%ebp)
 2a6:	e8 55 03 00 00       	call   600 <memmove>
      p[DIRSIZ] = 0;
 2ab:	8b 85 a8 fd ff ff    	mov    -0x258(%ebp),%eax
 2b1:	c6 40 0f 00          	movb   $0x0,0xf(%eax)
      if (stat(buf, &st) < 0)
 2b5:	58                   	pop    %eax
 2b6:	5a                   	pop    %edx
 2b7:	56                   	push   %esi
 2b8:	57                   	push   %edi
 2b9:	e8 a2 02 00 00       	call   560 <stat>
 2be:	83 c4 10             	add    $0x10,%esp
 2c1:	85 c0                	test   %eax,%eax
 2c3:	0f 88 a7 00 00 00    	js     370 <ls+0x200>
      printf(1, "%s %d %d %d\n", fmtname(buf, st.type == T_DIR), st.type, st.ino, st.size);
 2c9:	0f b7 95 d4 fd ff ff 	movzwl -0x22c(%ebp),%edx
 2d0:	8b 85 dc fd ff ff    	mov    -0x224(%ebp),%eax
 2d6:	83 ec 08             	sub    $0x8,%esp
 2d9:	8b 8d e4 fd ff ff    	mov    -0x21c(%ebp),%ecx
 2df:	66 83 fa 01          	cmp    $0x1,%dx
 2e3:	89 85 b4 fd ff ff    	mov    %eax,-0x24c(%ebp)
 2e9:	0f 94 c0             	sete   %al
 2ec:	89 8d ac fd ff ff    	mov    %ecx,-0x254(%ebp)
 2f2:	0f b6 c0             	movzbl %al,%eax
 2f5:	89 95 b0 fd ff ff    	mov    %edx,-0x250(%ebp)
 2fb:	50                   	push   %eax
 2fc:	57                   	push   %edi
 2fd:	e8 9e fd ff ff       	call   a0 <fmtname>
 302:	5a                   	pop    %edx
 303:	59                   	pop    %ecx
 304:	8b 8d ac fd ff ff    	mov    -0x254(%ebp),%ecx
 30a:	51                   	push   %ecx
 30b:	ff b5 b4 fd ff ff    	push   -0x24c(%ebp)
 311:	0f bf 95 b0 fd ff ff 	movswl -0x250(%ebp),%edx
 318:	52                   	push   %edx
 319:	50                   	push   %eax
 31a:	68 30 0b 00 00       	push   $0xb30
 31f:	6a 01                	push   $0x1
 321:	e8 7a 04 00 00       	call   7a0 <printf>
 326:	83 c4 20             	add    $0x20,%esp
 329:	e9 32 ff ff ff       	jmp    260 <ls+0xf0>
 32e:	66 90                	xchg   %ax,%ax
    printf(2, "ls: cannot open %s\n", path);
 330:	83 ec 04             	sub    $0x4,%esp
 333:	57                   	push   %edi
 334:	68 08 0b 00 00       	push   $0xb08
 339:	6a 02                	push   $0x2
 33b:	e8 60 04 00 00       	call   7a0 <printf>
    return;
 340:	83 c4 10             	add    $0x10,%esp
}
 343:	8d 65 f4             	lea    -0xc(%ebp),%esp
 346:	5b                   	pop    %ebx
 347:	5e                   	pop    %esi
 348:	5f                   	pop    %edi
 349:	5d                   	pop    %ebp
 34a:	c3                   	ret
 34b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      printf(1, "ls: path too long\n");
 350:	83 ec 08             	sub    $0x8,%esp
 353:	68 3d 0b 00 00       	push   $0xb3d
 358:	6a 01                	push   $0x1
 35a:	e8 41 04 00 00       	call   7a0 <printf>
      break;
 35f:	83 c4 10             	add    $0x10,%esp
 362:	e9 94 fe ff ff       	jmp    1fb <ls+0x8b>
 367:	90                   	nop
 368:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 36f:	00 
        printf(1, "ls: cannot stat %s\n", buf);
 370:	83 ec 04             	sub    $0x4,%esp
 373:	57                   	push   %edi
 374:	68 1c 0b 00 00       	push   $0xb1c
 379:	6a 01                	push   $0x1
 37b:	e8 20 04 00 00       	call   7a0 <printf>
        continue;
 380:	83 c4 10             	add    $0x10,%esp
 383:	e9 d8 fe ff ff       	jmp    260 <ls+0xf0>
 388:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 38f:	00 
    printf(2, "ls: cannot stat %s\n", path);
 390:	83 ec 04             	sub    $0x4,%esp
 393:	57                   	push   %edi
 394:	68 1c 0b 00 00       	push   $0xb1c
 399:	6a 02                	push   $0x2
 39b:	e8 00 04 00 00       	call   7a0 <printf>
    close(fd);
 3a0:	89 1c 24             	mov    %ebx,(%esp)
 3a3:	e8 b3 02 00 00       	call   65b <close>
    return;
 3a8:	83 c4 10             	add    $0x10,%esp
}
 3ab:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3ae:	5b                   	pop    %ebx
 3af:	5e                   	pop    %esi
 3b0:	5f                   	pop    %edi
 3b1:	5d                   	pop    %ebp
 3b2:	c3                   	ret
 3b3:	66 90                	xchg   %ax,%ax
 3b5:	66 90                	xchg   %ax,%ax
 3b7:	66 90                	xchg   %ax,%ax
 3b9:	66 90                	xchg   %ax,%ax
 3bb:	66 90                	xchg   %ax,%ax
 3bd:	66 90                	xchg   %ax,%ax
 3bf:	90                   	nop

000003c0 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 3c0:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 3c1:	31 c0                	xor    %eax,%eax
{
 3c3:	89 e5                	mov    %esp,%ebp
 3c5:	53                   	push   %ebx
 3c6:	8b 4d 08             	mov    0x8(%ebp),%ecx
 3c9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 3cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 3d0:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 3d4:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 3d7:	83 c0 01             	add    $0x1,%eax
 3da:	84 d2                	test   %dl,%dl
 3dc:	75 f2                	jne    3d0 <strcpy+0x10>
    ;
  return os;
}
 3de:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 3e1:	89 c8                	mov    %ecx,%eax
 3e3:	c9                   	leave
 3e4:	c3                   	ret
 3e5:	8d 76 00             	lea    0x0(%esi),%esi
 3e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 3ef:	00 

000003f0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 3f0:	55                   	push   %ebp
 3f1:	89 e5                	mov    %esp,%ebp
 3f3:	53                   	push   %ebx
 3f4:	8b 55 08             	mov    0x8(%ebp),%edx
 3f7:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 3fa:	0f b6 02             	movzbl (%edx),%eax
 3fd:	84 c0                	test   %al,%al
 3ff:	75 2d                	jne    42e <strcmp+0x3e>
 401:	eb 4a                	jmp    44d <strcmp+0x5d>
 403:	eb 1b                	jmp    420 <strcmp+0x30>
 405:	8d 76 00             	lea    0x0(%esi),%esi
 408:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 40f:	00 
 410:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 417:	00 
 418:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 41f:	00 
 420:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 424:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 427:	84 c0                	test   %al,%al
 429:	74 15                	je     440 <strcmp+0x50>
 42b:	83 c1 01             	add    $0x1,%ecx
 42e:	0f b6 19             	movzbl (%ecx),%ebx
 431:	38 c3                	cmp    %al,%bl
 433:	74 eb                	je     420 <strcmp+0x30>
  return (uchar)*p - (uchar)*q;
 435:	29 d8                	sub    %ebx,%eax
}
 437:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 43a:	c9                   	leave
 43b:	c3                   	ret
 43c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return (uchar)*p - (uchar)*q;
 440:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 444:	31 c0                	xor    %eax,%eax
 446:	29 d8                	sub    %ebx,%eax
}
 448:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 44b:	c9                   	leave
 44c:	c3                   	ret
  return (uchar)*p - (uchar)*q;
 44d:	0f b6 19             	movzbl (%ecx),%ebx
 450:	31 c0                	xor    %eax,%eax
 452:	eb e1                	jmp    435 <strcmp+0x45>
 454:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 458:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 45f:	00 

00000460 <strlen>:

uint
strlen(const char *s)
{
 460:	55                   	push   %ebp
 461:	89 e5                	mov    %esp,%ebp
 463:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 466:	80 3a 00             	cmpb   $0x0,(%edx)
 469:	74 15                	je     480 <strlen+0x20>
 46b:	31 c0                	xor    %eax,%eax
 46d:	8d 76 00             	lea    0x0(%esi),%esi
 470:	83 c0 01             	add    $0x1,%eax
 473:	89 c1                	mov    %eax,%ecx
 475:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 479:	75 f5                	jne    470 <strlen+0x10>
    ;
  return n;
}
 47b:	89 c8                	mov    %ecx,%eax
 47d:	5d                   	pop    %ebp
 47e:	c3                   	ret
 47f:	90                   	nop
  for(n = 0; s[n]; n++)
 480:	31 c9                	xor    %ecx,%ecx
}
 482:	5d                   	pop    %ebp
 483:	89 c8                	mov    %ecx,%eax
 485:	c3                   	ret
 486:	66 90                	xchg   %ax,%ax
 488:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 48f:	00 

00000490 <memset>:

void*
memset(void *dst, int c, uint n)
{
 490:	55                   	push   %ebp
 491:	89 e5                	mov    %esp,%ebp
 493:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 494:	8b 4d 10             	mov    0x10(%ebp),%ecx
 497:	8b 45 0c             	mov    0xc(%ebp),%eax
 49a:	8b 7d 08             	mov    0x8(%ebp),%edi
 49d:	fc                   	cld
 49e:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 4a0:	8b 45 08             	mov    0x8(%ebp),%eax
 4a3:	8b 7d fc             	mov    -0x4(%ebp),%edi
 4a6:	c9                   	leave
 4a7:	c3                   	ret
 4a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4af:	00 

000004b0 <strchr>:

char*
strchr(const char *s, char c)
{
 4b0:	55                   	push   %ebp
 4b1:	89 e5                	mov    %esp,%ebp
 4b3:	8b 45 08             	mov    0x8(%ebp),%eax
 4b6:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 4ba:	0f b6 10             	movzbl (%eax),%edx
 4bd:	84 d2                	test   %dl,%dl
 4bf:	75 1a                	jne    4db <strchr+0x2b>
 4c1:	eb 25                	jmp    4e8 <strchr+0x38>
 4c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 4c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4cf:	00 
 4d0:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 4d4:	83 c0 01             	add    $0x1,%eax
 4d7:	84 d2                	test   %dl,%dl
 4d9:	74 0d                	je     4e8 <strchr+0x38>
    if(*s == c)
 4db:	38 d1                	cmp    %dl,%cl
 4dd:	75 f1                	jne    4d0 <strchr+0x20>
      return (char*)s;
  return 0;
}
 4df:	5d                   	pop    %ebp
 4e0:	c3                   	ret
 4e1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 4e8:	31 c0                	xor    %eax,%eax
}
 4ea:	5d                   	pop    %ebp
 4eb:	c3                   	ret
 4ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000004f0 <gets>:

char*
gets(char *buf, int max)
{
 4f0:	55                   	push   %ebp
 4f1:	89 e5                	mov    %esp,%ebp
 4f3:	57                   	push   %edi
 4f4:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 4f5:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
 4f8:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 4f9:	31 db                	xor    %ebx,%ebx
{
 4fb:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 4fe:	eb 27                	jmp    527 <gets+0x37>
    cc = read(0, &c, 1);
 500:	83 ec 04             	sub    $0x4,%esp
 503:	6a 01                	push   $0x1
 505:	57                   	push   %edi
 506:	6a 00                	push   $0x0
 508:	e8 3e 01 00 00       	call   64b <read>
    if(cc < 1)
 50d:	83 c4 10             	add    $0x10,%esp
 510:	85 c0                	test   %eax,%eax
 512:	7e 1d                	jle    531 <gets+0x41>
      break;
    buf[i++] = c;
 514:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 518:	8b 55 08             	mov    0x8(%ebp),%edx
 51b:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 51f:	3c 0a                	cmp    $0xa,%al
 521:	74 1d                	je     540 <gets+0x50>
 523:	3c 0d                	cmp    $0xd,%al
 525:	74 19                	je     540 <gets+0x50>
  for(i=0; i+1 < max; ){
 527:	89 de                	mov    %ebx,%esi
 529:	83 c3 01             	add    $0x1,%ebx
 52c:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 52f:	7c cf                	jl     500 <gets+0x10>
      break;
  }
  buf[i] = '\0';
 531:	8b 45 08             	mov    0x8(%ebp),%eax
 534:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 538:	8d 65 f4             	lea    -0xc(%ebp),%esp
 53b:	5b                   	pop    %ebx
 53c:	5e                   	pop    %esi
 53d:	5f                   	pop    %edi
 53e:	5d                   	pop    %ebp
 53f:	c3                   	ret
  buf[i] = '\0';
 540:	8b 45 08             	mov    0x8(%ebp),%eax
    buf[i++] = c;
 543:	89 de                	mov    %ebx,%esi
  buf[i] = '\0';
 545:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
 549:	8d 65 f4             	lea    -0xc(%ebp),%esp
 54c:	5b                   	pop    %ebx
 54d:	5e                   	pop    %esi
 54e:	5f                   	pop    %edi
 54f:	5d                   	pop    %ebp
 550:	c3                   	ret
 551:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 558:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 55f:	00 

00000560 <stat>:

int
stat(const char *n, struct stat *st)
{
 560:	55                   	push   %ebp
 561:	89 e5                	mov    %esp,%ebp
 563:	56                   	push   %esi
 564:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 565:	83 ec 08             	sub    $0x8,%esp
 568:	6a 00                	push   $0x0
 56a:	ff 75 08             	push   0x8(%ebp)
 56d:	e8 01 01 00 00       	call   673 <open>
  if(fd < 0)
 572:	83 c4 10             	add    $0x10,%esp
 575:	85 c0                	test   %eax,%eax
 577:	78 27                	js     5a0 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 579:	83 ec 08             	sub    $0x8,%esp
 57c:	ff 75 0c             	push   0xc(%ebp)
 57f:	89 c3                	mov    %eax,%ebx
 581:	50                   	push   %eax
 582:	e8 04 01 00 00       	call   68b <fstat>
  close(fd);
 587:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 58a:	89 c6                	mov    %eax,%esi
  close(fd);
 58c:	e8 ca 00 00 00       	call   65b <close>
  return r;
 591:	83 c4 10             	add    $0x10,%esp
}
 594:	8d 65 f8             	lea    -0x8(%ebp),%esp
 597:	89 f0                	mov    %esi,%eax
 599:	5b                   	pop    %ebx
 59a:	5e                   	pop    %esi
 59b:	5d                   	pop    %ebp
 59c:	c3                   	ret
 59d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 5a0:	be ff ff ff ff       	mov    $0xffffffff,%esi
 5a5:	eb ed                	jmp    594 <stat+0x34>
 5a7:	90                   	nop
 5a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 5af:	00 

000005b0 <atoi>:

int
atoi(const char *s)
{
 5b0:	55                   	push   %ebp
 5b1:	89 e5                	mov    %esp,%ebp
 5b3:	53                   	push   %ebx
 5b4:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 5b7:	0f be 02             	movsbl (%edx),%eax
 5ba:	8d 48 d0             	lea    -0x30(%eax),%ecx
 5bd:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 5c0:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 5c5:	77 2e                	ja     5f5 <atoi+0x45>
 5c7:	eb 17                	jmp    5e0 <atoi+0x30>
 5c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 5d0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 5d7:	00 
 5d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 5df:	00 
    n = n*10 + *s++ - '0';
 5e0:	83 c2 01             	add    $0x1,%edx
 5e3:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 5e6:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 5ea:	0f be 02             	movsbl (%edx),%eax
 5ed:	8d 58 d0             	lea    -0x30(%eax),%ebx
 5f0:	80 fb 09             	cmp    $0x9,%bl
 5f3:	76 eb                	jbe    5e0 <atoi+0x30>
  return n;
}
 5f5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 5f8:	89 c8                	mov    %ecx,%eax
 5fa:	c9                   	leave
 5fb:	c3                   	ret
 5fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000600 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 600:	55                   	push   %ebp
 601:	89 e5                	mov    %esp,%ebp
 603:	57                   	push   %edi
 604:	8b 45 10             	mov    0x10(%ebp),%eax
 607:	8b 55 08             	mov    0x8(%ebp),%edx
 60a:	56                   	push   %esi
 60b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 60e:	85 c0                	test   %eax,%eax
 610:	7e 13                	jle    625 <memmove+0x25>
 612:	01 d0                	add    %edx,%eax
  dst = vdst;
 614:	89 d7                	mov    %edx,%edi
 616:	66 90                	xchg   %ax,%ax
 618:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 61f:	00 
    *dst++ = *src++;
 620:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 621:	39 f8                	cmp    %edi,%eax
 623:	75 fb                	jne    620 <memmove+0x20>
  return vdst;
}
 625:	5e                   	pop    %esi
 626:	89 d0                	mov    %edx,%eax
 628:	5f                   	pop    %edi
 629:	5d                   	pop    %ebp
 62a:	c3                   	ret

0000062b <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 62b:	b8 01 00 00 00       	mov    $0x1,%eax
 630:	cd 40                	int    $0x40
 632:	c3                   	ret

00000633 <exit>:
SYSCALL(exit)
 633:	b8 02 00 00 00       	mov    $0x2,%eax
 638:	cd 40                	int    $0x40
 63a:	c3                   	ret

0000063b <wait>:
SYSCALL(wait)
 63b:	b8 03 00 00 00       	mov    $0x3,%eax
 640:	cd 40                	int    $0x40
 642:	c3                   	ret

00000643 <pipe>:
SYSCALL(pipe)
 643:	b8 04 00 00 00       	mov    $0x4,%eax
 648:	cd 40                	int    $0x40
 64a:	c3                   	ret

0000064b <read>:
SYSCALL(read)
 64b:	b8 05 00 00 00       	mov    $0x5,%eax
 650:	cd 40                	int    $0x40
 652:	c3                   	ret

00000653 <write>:
SYSCALL(write)
 653:	b8 10 00 00 00       	mov    $0x10,%eax
 658:	cd 40                	int    $0x40
 65a:	c3                   	ret

0000065b <close>:
SYSCALL(close)
 65b:	b8 15 00 00 00       	mov    $0x15,%eax
 660:	cd 40                	int    $0x40
 662:	c3                   	ret

00000663 <kill>:
SYSCALL(kill)
 663:	b8 06 00 00 00       	mov    $0x6,%eax
 668:	cd 40                	int    $0x40
 66a:	c3                   	ret

0000066b <exec>:
SYSCALL(exec)
 66b:	b8 07 00 00 00       	mov    $0x7,%eax
 670:	cd 40                	int    $0x40
 672:	c3                   	ret

00000673 <open>:
SYSCALL(open)
 673:	b8 0f 00 00 00       	mov    $0xf,%eax
 678:	cd 40                	int    $0x40
 67a:	c3                   	ret

0000067b <mknod>:
SYSCALL(mknod)
 67b:	b8 11 00 00 00       	mov    $0x11,%eax
 680:	cd 40                	int    $0x40
 682:	c3                   	ret

00000683 <unlink>:
SYSCALL(unlink)
 683:	b8 12 00 00 00       	mov    $0x12,%eax
 688:	cd 40                	int    $0x40
 68a:	c3                   	ret

0000068b <fstat>:
SYSCALL(fstat)
 68b:	b8 08 00 00 00       	mov    $0x8,%eax
 690:	cd 40                	int    $0x40
 692:	c3                   	ret

00000693 <link>:
SYSCALL(link)
 693:	b8 13 00 00 00       	mov    $0x13,%eax
 698:	cd 40                	int    $0x40
 69a:	c3                   	ret

0000069b <mkdir>:
SYSCALL(mkdir)
 69b:	b8 14 00 00 00       	mov    $0x14,%eax
 6a0:	cd 40                	int    $0x40
 6a2:	c3                   	ret

000006a3 <chdir>:
SYSCALL(chdir)
 6a3:	b8 09 00 00 00       	mov    $0x9,%eax
 6a8:	cd 40                	int    $0x40
 6aa:	c3                   	ret

000006ab <dup>:
SYSCALL(dup)
 6ab:	b8 0a 00 00 00       	mov    $0xa,%eax
 6b0:	cd 40                	int    $0x40
 6b2:	c3                   	ret

000006b3 <getpid>:
SYSCALL(getpid)
 6b3:	b8 0b 00 00 00       	mov    $0xb,%eax
 6b8:	cd 40                	int    $0x40
 6ba:	c3                   	ret

000006bb <sbrk>:
SYSCALL(sbrk)
 6bb:	b8 0c 00 00 00       	mov    $0xc,%eax
 6c0:	cd 40                	int    $0x40
 6c2:	c3                   	ret

000006c3 <sleep>:
SYSCALL(sleep)
 6c3:	b8 0d 00 00 00       	mov    $0xd,%eax
 6c8:	cd 40                	int    $0x40
 6ca:	c3                   	ret

000006cb <uptime>:
SYSCALL(uptime)
 6cb:	b8 0e 00 00 00       	mov    $0xe,%eax
 6d0:	cd 40                	int    $0x40
 6d2:	c3                   	ret

000006d3 <hello>:
SYSCALL(hello)
 6d3:	b8 16 00 00 00       	mov    $0x16,%eax
 6d8:	cd 40                	int    $0x40
 6da:	c3                   	ret
 6db:	66 90                	xchg   %ax,%ax
 6dd:	66 90                	xchg   %ax,%ax
 6df:	90                   	nop

000006e0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 6e0:	55                   	push   %ebp
 6e1:	89 e5                	mov    %esp,%ebp
 6e3:	57                   	push   %edi
 6e4:	56                   	push   %esi
 6e5:	53                   	push   %ebx
 6e6:	89 cb                	mov    %ecx,%ebx
 6e8:	83 ec 3c             	sub    $0x3c,%esp
 6eb:	89 45 c4             	mov    %eax,-0x3c(%ebp)
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 6ee:	85 d2                	test   %edx,%edx
 6f0:	0f 89 9a 00 00 00    	jns    790 <printint+0xb0>
 6f6:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 6fa:	0f 84 90 00 00 00    	je     790 <printint+0xb0>
    neg = 1;
    x = -xx;
 700:	f7 da                	neg    %edx
    neg = 1;
 702:	b8 01 00 00 00       	mov    $0x1,%eax
 707:	89 45 c0             	mov    %eax,-0x40(%ebp)
 70a:	89 d1                	mov    %edx,%ecx
  } else {
    x = xx;
  }

  i = 0;
 70c:	31 f6                	xor    %esi,%esi
 70e:	66 90                	xchg   %ax,%ax
 710:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 717:	00 
 718:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 71f:	00 
  do{
    buf[i++] = digits[x % base];
 720:	89 c8                	mov    %ecx,%eax
 722:	31 d2                	xor    %edx,%edx
 724:	89 f7                	mov    %esi,%edi
 726:	f7 f3                	div    %ebx
 728:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
 72b:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
 72d:	0f b6 92 b4 0b 00 00 	movzbl 0xbb4(%edx),%edx
  }while((x /= base) != 0);
 734:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
 736:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 73a:	73 e4                	jae    720 <printint+0x40>
  if(neg)
 73c:	8b 45 c0             	mov    -0x40(%ebp),%eax
 73f:	85 c0                	test   %eax,%eax
 741:	74 07                	je     74a <printint+0x6a>
    buf[i++] = '-';
 743:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
 748:	89 f7                	mov    %esi,%edi

  while(--i >= 0)
 74a:	8d 74 3d d8          	lea    -0x28(%ebp,%edi,1),%esi
 74e:	8b 7d c4             	mov    -0x3c(%ebp),%edi
 751:	8d 5d d7             	lea    -0x29(%ebp),%ebx
 754:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 758:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 75f:	00 
    putc(fd, buf[i]);
 760:	0f b6 06             	movzbl (%esi),%eax
  write(fd, &c, 1);
 763:	83 ec 04             	sub    $0x4,%esp
  while(--i >= 0)
 766:	83 ee 01             	sub    $0x1,%esi
 769:	88 45 d7             	mov    %al,-0x29(%ebp)
  write(fd, &c, 1);
 76c:	8d 45 d7             	lea    -0x29(%ebp),%eax
 76f:	6a 01                	push   $0x1
 771:	50                   	push   %eax
 772:	57                   	push   %edi
 773:	e8 db fe ff ff       	call   653 <write>
  while(--i >= 0)
 778:	83 c4 10             	add    $0x10,%esp
 77b:	39 f3                	cmp    %esi,%ebx
 77d:	75 e1                	jne    760 <printint+0x80>
}
 77f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 782:	5b                   	pop    %ebx
 783:	5e                   	pop    %esi
 784:	5f                   	pop    %edi
 785:	5d                   	pop    %ebp
 786:	c3                   	ret
 787:	90                   	nop
 788:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 78f:	00 
  neg = 0;
 790:	31 c0                	xor    %eax,%eax
 792:	e9 70 ff ff ff       	jmp    707 <printint+0x27>
 797:	90                   	nop
 798:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 79f:	00 

000007a0 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 7a0:	55                   	push   %ebp
 7a1:	89 e5                	mov    %esp,%ebp
 7a3:	57                   	push   %edi
 7a4:	56                   	push   %esi
 7a5:	53                   	push   %ebx
 7a6:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 7a9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
 7ac:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
 7af:	0f b6 13             	movzbl (%ebx),%edx
 7b2:	83 c3 01             	add    $0x1,%ebx
 7b5:	84 d2                	test   %dl,%dl
 7b7:	0f 84 a0 00 00 00    	je     85d <printf+0xbd>
 7bd:	8d 45 10             	lea    0x10(%ebp),%eax
 7c0:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    c = fmt[i] & 0xff;
 7c3:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 7c6:	0f b6 c2             	movzbl %dl,%eax
    if(state == 0){
 7c9:	eb 28                	jmp    7f3 <printf+0x53>
 7cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
 7d0:	83 ec 04             	sub    $0x4,%esp
 7d3:	8d 45 e7             	lea    -0x19(%ebp),%eax
 7d6:	88 55 e7             	mov    %dl,-0x19(%ebp)
  for(i = 0; fmt[i]; i++){
 7d9:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 7dc:	6a 01                	push   $0x1
 7de:	50                   	push   %eax
 7df:	56                   	push   %esi
 7e0:	e8 6e fe ff ff       	call   653 <write>
  for(i = 0; fmt[i]; i++){
 7e5:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
 7e9:	83 c4 10             	add    $0x10,%esp
 7ec:	84 d2                	test   %dl,%dl
 7ee:	74 6d                	je     85d <printf+0xbd>
    c = fmt[i] & 0xff;
 7f0:	0f b6 c2             	movzbl %dl,%eax
      if(c == '%'){
 7f3:	83 f8 25             	cmp    $0x25,%eax
 7f6:	75 d8                	jne    7d0 <printf+0x30>
  for(i = 0; fmt[i]; i++){
 7f8:	0f b6 13             	movzbl (%ebx),%edx
 7fb:	84 d2                	test   %dl,%dl
 7fd:	74 5e                	je     85d <printf+0xbd>
    c = fmt[i] & 0xff;
 7ff:	0f b6 c2             	movzbl %dl,%eax
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
      if(c == 'd'){
 802:	80 fa 25             	cmp    $0x25,%dl
 805:	0f 84 25 01 00 00    	je     930 <printf+0x190>
 80b:	83 e8 63             	sub    $0x63,%eax
 80e:	83 f8 15             	cmp    $0x15,%eax
 811:	77 0d                	ja     820 <printf+0x80>
 813:	ff 24 85 5c 0b 00 00 	jmp    *0xb5c(,%eax,4)
 81a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 820:	83 ec 04             	sub    $0x4,%esp
 823:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 826:	88 55 d0             	mov    %dl,-0x30(%ebp)
        ap++;
      } else if(c == '%'){
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 829:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 82d:	6a 01                	push   $0x1
 82f:	51                   	push   %ecx
 830:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
 833:	56                   	push   %esi
 834:	e8 1a fe ff ff       	call   653 <write>
        putc(fd, c);
 839:	0f b6 55 d0          	movzbl -0x30(%ebp),%edx
  write(fd, &c, 1);
 83d:	83 c4 0c             	add    $0xc,%esp
 840:	88 55 e7             	mov    %dl,-0x19(%ebp)
 843:	6a 01                	push   $0x1
 845:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 848:	51                   	push   %ecx
  for(i = 0; fmt[i]; i++){
 849:	83 c3 02             	add    $0x2,%ebx
  write(fd, &c, 1);
 84c:	56                   	push   %esi
 84d:	e8 01 fe ff ff       	call   653 <write>
  for(i = 0; fmt[i]; i++){
 852:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
 856:	83 c4 10             	add    $0x10,%esp
 859:	84 d2                	test   %dl,%dl
 85b:	75 93                	jne    7f0 <printf+0x50>
      }
      state = 0;
    }
  }
}
 85d:	8d 65 f4             	lea    -0xc(%ebp),%esp
 860:	5b                   	pop    %ebx
 861:	5e                   	pop    %esi
 862:	5f                   	pop    %edi
 863:	5d                   	pop    %ebp
 864:	c3                   	ret
 865:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 16, 0);
 868:	83 ec 0c             	sub    $0xc,%esp
 86b:	8b 17                	mov    (%edi),%edx
 86d:	b9 10 00 00 00       	mov    $0x10,%ecx
 872:	89 f0                	mov    %esi,%eax
 874:	6a 00                	push   $0x0
 876:	e8 65 fe ff ff       	call   6e0 <printint>
  for(i = 0; fmt[i]; i++){
 87b:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 87f:	83 c3 02             	add    $0x2,%ebx
 882:	83 c4 10             	add    $0x10,%esp
 885:	84 d2                	test   %dl,%dl
 887:	74 d4                	je     85d <printf+0xbd>
        ap++;
 889:	83 c7 04             	add    $0x4,%edi
 88c:	e9 5f ff ff ff       	jmp    7f0 <printf+0x50>
 891:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        s = (char*)*ap;
 898:	8b 07                	mov    (%edi),%eax
        ap++;
 89a:	83 c7 04             	add    $0x4,%edi
        if(s == 0)
 89d:	85 c0                	test   %eax,%eax
 89f:	0f 84 9b 00 00 00    	je     940 <printf+0x1a0>
        while(*s != 0){
 8a5:	0f b6 10             	movzbl (%eax),%edx
 8a8:	84 d2                	test   %dl,%dl
 8aa:	0f 84 a2 00 00 00    	je     952 <printf+0x1b2>
 8b0:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 8b3:	89 c7                	mov    %eax,%edi
 8b5:	89 d0                	mov    %edx,%eax
 8b7:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 8ba:	89 fb                	mov    %edi,%ebx
 8bc:	8d 7d e7             	lea    -0x19(%ebp),%edi
 8bf:	90                   	nop
  write(fd, &c, 1);
 8c0:	83 ec 04             	sub    $0x4,%esp
 8c3:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
 8c6:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 8c9:	6a 01                	push   $0x1
 8cb:	57                   	push   %edi
 8cc:	56                   	push   %esi
 8cd:	e8 81 fd ff ff       	call   653 <write>
        while(*s != 0){
 8d2:	0f b6 03             	movzbl (%ebx),%eax
 8d5:	83 c4 10             	add    $0x10,%esp
 8d8:	84 c0                	test   %al,%al
 8da:	75 e4                	jne    8c0 <printf+0x120>
 8dc:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  for(i = 0; fmt[i]; i++){
 8df:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 8e3:	83 c3 02             	add    $0x2,%ebx
 8e6:	84 d2                	test   %dl,%dl
 8e8:	0f 85 d5 fe ff ff    	jne    7c3 <printf+0x23>
 8ee:	e9 6a ff ff ff       	jmp    85d <printf+0xbd>
 8f3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 10, 1);
 8f8:	83 ec 0c             	sub    $0xc,%esp
 8fb:	8b 17                	mov    (%edi),%edx
 8fd:	b9 0a 00 00 00       	mov    $0xa,%ecx
 902:	89 f0                	mov    %esi,%eax
 904:	6a 01                	push   $0x1
 906:	e8 d5 fd ff ff       	call   6e0 <printint>
  for(i = 0; fmt[i]; i++){
 90b:	e9 6b ff ff ff       	jmp    87b <printf+0xdb>
        putc(fd, *ap);
 910:	8b 07                	mov    (%edi),%eax
  write(fd, &c, 1);
 912:	83 ec 04             	sub    $0x4,%esp
 915:	8d 4d e7             	lea    -0x19(%ebp),%ecx
        putc(fd, *ap);
 918:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 91b:	6a 01                	push   $0x1
 91d:	51                   	push   %ecx
 91e:	56                   	push   %esi
 91f:	e8 2f fd ff ff       	call   653 <write>
 924:	e9 52 ff ff ff       	jmp    87b <printf+0xdb>
 929:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 930:	83 ec 04             	sub    $0x4,%esp
 933:	88 55 e7             	mov    %dl,-0x19(%ebp)
 936:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 939:	6a 01                	push   $0x1
 93b:	e9 08 ff ff ff       	jmp    848 <printf+0xa8>
          s = "(null)";
 940:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 943:	b8 28 00 00 00       	mov    $0x28,%eax
 948:	bf 55 0b 00 00       	mov    $0xb55,%edi
 94d:	e9 65 ff ff ff       	jmp    8b7 <printf+0x117>
  for(i = 0; fmt[i]; i++){
 952:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 956:	83 c3 02             	add    $0x2,%ebx
 959:	84 d2                	test   %dl,%dl
 95b:	0f 85 8f fe ff ff    	jne    7f0 <printf+0x50>
 961:	e9 f7 fe ff ff       	jmp    85d <printf+0xbd>
 966:	66 90                	xchg   %ax,%ax
 968:	66 90                	xchg   %ax,%ax
 96a:	66 90                	xchg   %ax,%ax
 96c:	66 90                	xchg   %ax,%ax
 96e:	66 90                	xchg   %ax,%ax
 970:	66 90                	xchg   %ax,%ax
 972:	66 90                	xchg   %ax,%ax
 974:	66 90                	xchg   %ax,%ax
 976:	66 90                	xchg   %ax,%ax
 978:	66 90                	xchg   %ax,%ax
 97a:	66 90                	xchg   %ax,%ax
 97c:	66 90                	xchg   %ax,%ax
 97e:	66 90                	xchg   %ax,%ax

00000980 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 980:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 981:	a1 fc 0e 00 00       	mov    0xefc,%eax
{
 986:	89 e5                	mov    %esp,%ebp
 988:	57                   	push   %edi
 989:	56                   	push   %esi
 98a:	53                   	push   %ebx
 98b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 98e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 991:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 998:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 99f:	00 
 9a0:	89 c2                	mov    %eax,%edx
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9a2:	8b 00                	mov    (%eax),%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9a4:	39 ca                	cmp    %ecx,%edx
 9a6:	73 30                	jae    9d8 <free+0x58>
 9a8:	39 c1                	cmp    %eax,%ecx
 9aa:	72 04                	jb     9b0 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9ac:	39 c2                	cmp    %eax,%edx
 9ae:	72 f0                	jb     9a0 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 9b0:	8b 73 fc             	mov    -0x4(%ebx),%esi
 9b3:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 9b6:	39 f8                	cmp    %edi,%eax
 9b8:	74 36                	je     9f0 <free+0x70>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 9ba:	89 43 f8             	mov    %eax,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 9bd:	8b 42 04             	mov    0x4(%edx),%eax
 9c0:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 9c3:	39 f1                	cmp    %esi,%ecx
 9c5:	74 40                	je     a07 <free+0x87>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 9c7:	89 0a                	mov    %ecx,(%edx)
  } else
    p->s.ptr = bp;
  freep = p;
}
 9c9:	5b                   	pop    %ebx
  freep = p;
 9ca:	89 15 fc 0e 00 00    	mov    %edx,0xefc
}
 9d0:	5e                   	pop    %esi
 9d1:	5f                   	pop    %edi
 9d2:	5d                   	pop    %ebp
 9d3:	c3                   	ret
 9d4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9d8:	39 c2                	cmp    %eax,%edx
 9da:	72 c4                	jb     9a0 <free+0x20>
 9dc:	39 c1                	cmp    %eax,%ecx
 9de:	73 c0                	jae    9a0 <free+0x20>
  if(bp + bp->s.size == p->s.ptr){
 9e0:	8b 73 fc             	mov    -0x4(%ebx),%esi
 9e3:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 9e6:	39 f8                	cmp    %edi,%eax
 9e8:	75 d0                	jne    9ba <free+0x3a>
 9ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp->s.size += p->s.ptr->s.size;
 9f0:	03 70 04             	add    0x4(%eax),%esi
 9f3:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 9f6:	8b 02                	mov    (%edx),%eax
 9f8:	8b 00                	mov    (%eax),%eax
 9fa:	89 43 f8             	mov    %eax,-0x8(%ebx)
  if(p + p->s.size == bp){
 9fd:	8b 42 04             	mov    0x4(%edx),%eax
 a00:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 a03:	39 f1                	cmp    %esi,%ecx
 a05:	75 c0                	jne    9c7 <free+0x47>
    p->s.size += bp->s.size;
 a07:	03 43 fc             	add    -0x4(%ebx),%eax
  freep = p;
 a0a:	89 15 fc 0e 00 00    	mov    %edx,0xefc
    p->s.size += bp->s.size;
 a10:	89 42 04             	mov    %eax,0x4(%edx)
    p->s.ptr = bp->s.ptr;
 a13:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 a16:	89 0a                	mov    %ecx,(%edx)
}
 a18:	5b                   	pop    %ebx
 a19:	5e                   	pop    %esi
 a1a:	5f                   	pop    %edi
 a1b:	5d                   	pop    %ebp
 a1c:	c3                   	ret
 a1d:	8d 76 00             	lea    0x0(%esi),%esi

00000a20 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a20:	55                   	push   %ebp
 a21:	89 e5                	mov    %esp,%ebp
 a23:	57                   	push   %edi
 a24:	56                   	push   %esi
 a25:	53                   	push   %ebx
 a26:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a29:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 a2c:	8b 15 fc 0e 00 00    	mov    0xefc,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a32:	8d 78 07             	lea    0x7(%eax),%edi
 a35:	c1 ef 03             	shr    $0x3,%edi
 a38:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 a3b:	85 d2                	test   %edx,%edx
 a3d:	0f 84 8d 00 00 00    	je     ad0 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a43:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 a45:	8b 48 04             	mov    0x4(%eax),%ecx
 a48:	39 f9                	cmp    %edi,%ecx
 a4a:	73 64                	jae    ab0 <malloc+0x90>
  if(nu < 4096)
 a4c:	bb 00 10 00 00       	mov    $0x1000,%ebx
 a51:	39 df                	cmp    %ebx,%edi
 a53:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 a56:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 a5d:	eb 0a                	jmp    a69 <malloc+0x49>
 a5f:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a60:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 a62:	8b 48 04             	mov    0x4(%eax),%ecx
 a65:	39 f9                	cmp    %edi,%ecx
 a67:	73 47                	jae    ab0 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a69:	89 c2                	mov    %eax,%edx
 a6b:	39 05 fc 0e 00 00    	cmp    %eax,0xefc
 a71:	75 ed                	jne    a60 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
 a73:	83 ec 0c             	sub    $0xc,%esp
 a76:	56                   	push   %esi
 a77:	e8 3f fc ff ff       	call   6bb <sbrk>
  if(p == (char*)-1)
 a7c:	83 c4 10             	add    $0x10,%esp
 a7f:	83 f8 ff             	cmp    $0xffffffff,%eax
 a82:	74 1c                	je     aa0 <malloc+0x80>
  hp->s.size = nu;
 a84:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 a87:	83 ec 0c             	sub    $0xc,%esp
 a8a:	83 c0 08             	add    $0x8,%eax
 a8d:	50                   	push   %eax
 a8e:	e8 ed fe ff ff       	call   980 <free>
  return freep;
 a93:	8b 15 fc 0e 00 00    	mov    0xefc,%edx
      if((p = morecore(nunits)) == 0)
 a99:	83 c4 10             	add    $0x10,%esp
 a9c:	85 d2                	test   %edx,%edx
 a9e:	75 c0                	jne    a60 <malloc+0x40>
        return 0;
  }
}
 aa0:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 aa3:	31 c0                	xor    %eax,%eax
}
 aa5:	5b                   	pop    %ebx
 aa6:	5e                   	pop    %esi
 aa7:	5f                   	pop    %edi
 aa8:	5d                   	pop    %ebp
 aa9:	c3                   	ret
 aaa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 ab0:	39 cf                	cmp    %ecx,%edi
 ab2:	74 4c                	je     b00 <malloc+0xe0>
        p->s.size -= nunits;
 ab4:	29 f9                	sub    %edi,%ecx
 ab6:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 ab9:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 abc:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 abf:	89 15 fc 0e 00 00    	mov    %edx,0xefc
}
 ac5:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 ac8:	83 c0 08             	add    $0x8,%eax
}
 acb:	5b                   	pop    %ebx
 acc:	5e                   	pop    %esi
 acd:	5f                   	pop    %edi
 ace:	5d                   	pop    %ebp
 acf:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
 ad0:	c7 05 fc 0e 00 00 00 	movl   $0xf00,0xefc
 ad7:	0f 00 00 
    base.s.size = 0;
 ada:	b8 00 0f 00 00       	mov    $0xf00,%eax
    base.s.ptr = freep = prevp = &base;
 adf:	c7 05 00 0f 00 00 00 	movl   $0xf00,0xf00
 ae6:	0f 00 00 
    base.s.size = 0;
 ae9:	c7 05 04 0f 00 00 00 	movl   $0x0,0xf04
 af0:	00 00 00 
    if(p->s.size >= nunits){
 af3:	e9 54 ff ff ff       	jmp    a4c <malloc+0x2c>
 af8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 aff:	00 
        prevp->s.ptr = p->s.ptr;
 b00:	8b 08                	mov    (%eax),%ecx
 b02:	89 0a                	mov    %ecx,(%edx)
 b04:	eb b9                	jmp    abf <malloc+0x9f>
