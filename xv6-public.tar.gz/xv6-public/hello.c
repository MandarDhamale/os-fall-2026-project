#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    printf(1, "Hello Xv6!\n");

    //system call into the kernel
    hello();
    
    exit();
}